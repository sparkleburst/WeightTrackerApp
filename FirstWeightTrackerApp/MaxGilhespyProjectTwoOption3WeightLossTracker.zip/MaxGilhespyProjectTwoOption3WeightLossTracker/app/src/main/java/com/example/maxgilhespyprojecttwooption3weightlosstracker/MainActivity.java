package com.example.maxgilhespyprojecttwooption3weightlosstracker;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /*

    The next methods are the beginnings of what to do (maybe) to get the permissions to work

    TODO: There are problems that need to be figured out

    public void onRequestPermission(View view) {
        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.SEND_SMS},
                REQUEST_SMS_PERMISSION);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == REQUEST_SMS_PERMISSION) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted. Send automated system notifications.
            } else {
                // Permission denied. App should still continue to function but no notifications will be sent.
            }
        }

    */

}